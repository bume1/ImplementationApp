# Project Tracker - Thrive 365 Labs

Multi-project launch tracker with 102-task templates, admin controls, and client portals.

## Quick Start
1. Upload to Replit as Node.js project
2. Run: `npm install`
3. Click "Run"
4. Login: bianca@thrive365labs.com / Thrive2025!

## Features
- Admin account with full controls
- User signup for team members
- 102-task Biolis AU480 CLIA template
- Client embeddable links (no login)
- HubSpot integration fields
- CSV export
